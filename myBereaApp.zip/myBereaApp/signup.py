'''
[Table of Contents]

1. Import Statements
2. SignupForm class
3. Signup Function

'''

from modules import * # Import all the modules from modules.py

class SignupForm(Form):
    """
    Uses wtform class for form validation. WTForm is a flask library
    """
    firstName = StringField('First Name', validators = [DataRequired(), Length(min = 2, max = 50)])
    username = StringField('User Name', validators = [DataRequired(), Length(min=4, max =25)])
    email = StringField('Email Address', validators = [DataRequired(), Length(min=6, max=50), Email()])
    password = PasswordField('Enter Password',
        validators = [DataRequired(),
        EqualTo('confirm', message='Passwords must match')
    ])
    confirm = PasswordField('Confirm Password')
    accept_tos = BooleanField('I accept the Terms of Service', [validators.DataRequired()])


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    """
    When users need to signup, this controller is for that
    """
    form = SignupForm(request.form)
    if request.method == 'POST' and form.validate():
        person, created = Users.get_or_create(email=form.email.data)
        if created:
            person.name = form.firstName.data
            person.username = form.username.data
            person.password = sha256_crypt.encrypt(str(form.password.data)) # protect users password by encrypting it
            person.save() #saves the persons information
            flash(" Thanks for registering. Please login to your account ", "success")
            return redirect(url_for("login"))
        else:
            flash("The email address is already in use. Please use a different email address!", "warning")
            return redirect(url_for('signup'))
    return render_template('signup.html', form = form)
