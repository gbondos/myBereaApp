'''
[Table of Contents]

1. Import Statements
2. JobForm class
3. Add Articles Function

'''

##### Import Modules for flask ############
from modules import *
from models.Jobs import Jobs
from flask import session
from login_required import *


######### Jobform Class #############
class JobForm(Form):
    ### This is a WTForm which ensures users security. It is flask library that uses validators
    title = StringField('Title', validators = [DataRequired(), Length(min = 1, max = 250)])
    body = TextAreaField('Body', validators = [DataRequired(), Length(min=4)])

@app.route("/add_jobs", methods=['GET', 'POST'])
@is_logged_in
def add_articles():
    '''
    This function is the controller for the add_jobs.html
    It gets the form data from the job form and save it as form. This data is saved to the database
    '''
    job = Jobs()
    form = JobForm(request.form)
    if request.method == 'POST' and form.validate(): # check if the form is valid
        job.title = form.title.data
        job.body = form.body.data
        job.author = session['name']
        job.save() # Save the job form to the database
        flash('You have successfully added a job to the dashboard.', 'success')
        return redirect(url_for('dashboard'))
    return render_template('add_jobs.html', form = form)
