

from peewee import * # THis import the peewee library. In order to use peewee, it has to be install with flask install peewee
DB = MySQLDatabase("myflaskapp", host="localhost", user="flask", password="flask2018") ### This is peewee configuration
# DB = MySQLDatabase("gbondos", port = 3306, host="tango.berea.edu", user="gbondos", passwd="Millionaire@at2019")

class DynamicModel(Model):
    class Meta:
        database = DB
