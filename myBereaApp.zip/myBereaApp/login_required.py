'''
[Table of Contents]

1. Import Statements
2. is_logged_in functon

'''
#### Import Statements ##########
from functools import wraps
from flask import session
from modules import *


def is_logged_in(f):
    """
    This is the decorator function to require users to login to the page
    Use this function to ensure only users that are logged in could access pages
    """
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return f(*args, **kwargs)
        else:
            flash('Unauthorized, please login', 'danger')
            return redirect(url_for('login'))
    return wrap
