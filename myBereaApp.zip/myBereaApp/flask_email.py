# '''
# [Table of Contents]
#
# 1. Import Statements
# 2. JobForm class
# 3. Add Articles Function
#
# '''
#
# ####### IMPORT Statements #########
# from app import *
# # from flask import request, url_for
# from flask_mail import Mail, Message # Flask mail is a library  from flask
# from itsdangerous import URLSafeTimedSerializer, SignatureExpired, BadTimeSignature
#
# s = URLSafeTimedSerializer('Thisisasecretkey!') # This is a token key
#
# app.config.update(
# 	DEBUG=True,
# 	#EMAIL SETTINGS
# 	MAIL_SERVER='smtp.gmail.com',
# 	MAIL_PORT=465,
# 	MAIL_USE_SSL=True,
#     MAIL_USE_TLS = False,
# 	MAIL_USERNAME = 'mosessaffagbondo@gmail.com',
# 	MAIL_PASSWORD = '@30'
# 	)
# # Follow this link and turn off gmail security app system: https://myaccount.google.com/lesssecureapps
#
# mail = Mail(app)
# @app.route('/email', methods=['GET', 'POST'])
# def email():
# 	"""
# 	This code is from flask mail library on configuring flask to send Mail
# 	"""
#     if request.method == 'GET':
#         return '<form action="" method="POST"><input name="email"><input type="submit"></form>'
#     email = request.form['email']
#     token = s.dumps(email, salt='email-confirm')
#     msg = Message("Hello", sender="mosessaffagbondo@gmail.com", recipients=[email])
#     link = url_for('confirm_email', token=token, _external=True)
#     msg.body = "Please confirm your email address by clicking on this link {}".format(link)
#     mail.send(msg)
#     # return "Sent"
#     return 'The email you entered is {} and the token is {} '.format(email, token)
#
# @app.route('/confirm_email/<token>')
# def confirm_email(token):
#     try:
#         email = s.loads(token, salt='email-confirm', max_age = 20)
#     except SignatureExpired:
#         return 'the confirmation link has expired'
#     except BadTimeSignature:
#         return 'This confirmation link has been modified. '
#     confirmation = False
#     return '<h1> The token works </h1>'
