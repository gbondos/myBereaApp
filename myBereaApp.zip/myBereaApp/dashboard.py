'''
[Table of Contents]

1. Import Statements
2. Dashboard Function

'''
#### Import Statements ##########

from flask import render_template
from models.Users import *
from models.Jobs import *
from login_required import *
from app import *


###### Dashboard Function #######
@app.route("/dashboard")
@is_logged_in
def dashboard():
    """
    This is the controller for the dashboard. It selects all the jobs from the database and renders it to
    the dashboard.html page
    """
    query = Jobs.select().execute() # Selects all jobs from the database
    if query:
        return render_template('dashboard.html', jobs = query) # Render all the jobs to the dashboard.html page
    else: # If no articles found
        msg = "No articles Found"
        return render_template('dashboard.html', msg=msg)
